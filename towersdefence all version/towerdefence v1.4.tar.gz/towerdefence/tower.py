import pygame
import os
from pygame import *
from pygame.time import *
from mygame4 import level
from settings import*
from mygame4 import all_bullets
import math

class MyTower(sprite.Sprite):
    image = []
    def __init__(self, x, y):
        sprite.Sprite.__init__(self)
        self.xvel = 0
        self.image = MyTower.image[0]
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.radius = 100
        self.firerite = 1000
    def draw(self, screen): 
        screen.blit(self.image, (self.rect.x,self.rect.y))
    def update(self, enemies, screen):
        trapped_enemy = pygame.sprite.spritecollide(self, enemies, False, pygame.sprite.collide_circle)
        for myenemy in trapped_enemy:
            for e in pygame.event.get():
                if e.type == SHOOT:
                    shoot = Bullets(myenemy.rect, self.rect)
                    shoot.rot_center()
                    all_bullets.add(shoot)
            all_bullets.draw(screen)
            all_bullets.update(myenemy)            
            
def create_tower(screen):
    positions = mouse.get_pos()
    MyTower.image.append(pygame.image.load(os.path.join("data","tower.png")))
    row= positions[0]/PLATFORM_WIDTH
    x = row*PLATFORM_WIDTH
    col= positions[1]/ PLATFORM_HEIGHT
    y =col* PLATFORM_HEIGHT
    # if not on enemy way
    if level[col][row] != '-':
        tower = MyTower(x, y)
    # center of tower
    center = (x+PLATFORM_WIDTH/2,y+PLATFORM_HEIGHT/2)
    return tower

class Bullets(sprite.Sprite):
    def __init__(self, enemy_cord, tower_cord):
        sprite.Sprite.__init__(self)
        self.xvel = (VELOCITY*(enemy_cord.x - tower_cord.x))/(math.fabs(enemy_cord.x - tower_cord.x)+math.fabs(enemy_cord.y - tower_cord.y))
        self.yvel = (VELOCITY*(enemy_cord.y - tower_cord.y))/(math.fabs(enemy_cord.x - tower_cord.x)+math.fabs(enemy_cord.y - tower_cord.y))
        
        self.enemy_cord = enemy_cord
        self.image = pygame.image.load(os.path.join("data","bullet.png"))
        self.rect = self.image.get_rect()
        self.rect.x = tower_cord.x 
        self.rect.y = tower_cord.y
        
    def update(self, myenemy):
        self.rect.x = self.rect.x + self.xvel
        self.rect.y = self.rect.y + self.yvel
        if sprite.collide_rect(self, myenemy):
            myenemy.kill()
            
    def rot_center(self):
        """rotate an image while keeping its center"""
        rot_image = pygame.transform.rotate(self.image, 45)
        rot_rect = rot_image.get_rect(center=self.rect.center)
        return rot_image,rot_rect        
        
    def draw(self, screen):
        screen.blit(self.image, (self.rect.x,self.rect.y))
