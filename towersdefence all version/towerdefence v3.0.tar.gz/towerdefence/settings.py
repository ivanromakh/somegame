import pygame

#display
WIN_WIDTH = 800 
WIN_HEIGHT = 500

# resolution
DISPLAY = (WIN_WIDTH, WIN_HEIGHT)
# shoot speed
VELOCITY = 20

ENEMYRATE, t1, trail = pygame.USEREVENT+1, 30000, []
SHOOT, t, trail = pygame.USEREVENT+2, 2000, []
#move speed
MOVE_SPEED = 6

#start point enemy
STARTx = 0
STARTy = 0

#nubers of platform
NUMBERS_WIDTH = 15
NUMBERS_HEIGHT = 8

# gamespeed
DIFICULT = 10

# numbers of finished enemies
HEALTH = 1

#size of platform
PLATFORM_WIDTH = WIN_WIDTH/NUMBERS_WIDTH
PLATFORM_HEIGHT = WIN_HEIGHT/NUMBERS_HEIGHT

#colours
BACKGROUND_COLOR = "#004400"
PLATFORM_COLOR = "#FF6262"
PLATFORM_COLOR1 = "#006262"

# way where enemy go "-"  
level = [
       "   -----       ",
       "   -   -       ",
       "   -   -       ",
       "s---   -------f",
       "               ",
       "               ",
       "               ",
       "               ",
       ]


