import pygame
import os
from pygame import *
from pygame.time import *
from settings import*
import math

class MyTower(sprite.Sprite):
    image = []
    def __init__(self, x, y):
        sprite.Sprite.__init__(self)
        self.xvel = 0
        self.image = MyTower.image[0]
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.bullets = pygame.sprite.Group()
        self.rect.y = y
        self.radius = 100
    def draw(self, screen): 
        screen.blit(self.image, (self.rect.x,self.rect.y))
    def update(self, myenemy):
        shoot = Bullets(myenemy.rect, self.rect)
        self.bullets.add(shoot)
        pygame.time.delay(1)
    def shotting(self, screen, allenemy):
        scop = 0
        for bult in self.bullets:
            scop = scop + bult.update(allenemy)
        self.bullets.draw(screen)
        return scop
            
            
def create_tower(screen):
    positions = mouse.get_pos()
    MyTower.image.append(pygame.image.load(os.path.join("data","mario.png")))
    row= positions[0]/PLATFORM_WIDTH
    x = row*PLATFORM_WIDTH
    col= positions[1]/ PLATFORM_HEIGHT
    y =col* PLATFORM_HEIGHT
    # if not on enemy way
    if level[col][row] != '-':
        tower = MyTower(x, y)
    # center of tower
    center = (x+PLATFORM_WIDTH/2,y+PLATFORM_HEIGHT/2)
    return tower

class Bullets(sprite.Sprite):
    def __init__(self, enemy_cord, tower_cord):
        sprite.Sprite.__init__(self)
        self.xvel = (VELOCITY*(enemy_cord.x - tower_cord.x))/(math.fabs(enemy_cord.x - tower_cord.x)+math.fabs(enemy_cord.y - tower_cord.y))
        self.yvel = (VELOCITY*(enemy_cord.y - tower_cord.y))/(math.fabs(enemy_cord.x - tower_cord.x)+math.fabs(enemy_cord.y - tower_cord.y))
        self.enemy_cord = enemy_cord
        self.tower_cord = tower_cord
        self.image = pygame.image.load(os.path.join("data","bullet.png"))
        self.rect = self.image.get_rect()
        self.rect.x = tower_cord.x 
        self.rect.y = tower_cord.y
        
    def update(self, allenemies):
        self.rect.x = self.rect.x + self.xvel
        self.rect.y = self.rect.y + self.yvel
        for enemy in allenemies:
            if sprite.collide_rect(self, enemy):
                enemy.health-=1
                if enemy.health == 0:
                    enemy.kill()
                    self.kill()
                    return 1
                self.kill()
        return 0
    def draw(self, screen):
        screen.blit(self.image, (self.rect.x,self.rect.y))
