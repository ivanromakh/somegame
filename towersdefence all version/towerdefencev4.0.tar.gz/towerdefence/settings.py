import pygame
import os

#display
WIN_WIDTH = 800 
WIN_HEIGHT = 500

# resolution
DISPLAY = (WIN_WIDTH, WIN_HEIGHT)
# shoot speed
VELOCITY = 20

ENEMYRATE, t1, trail = pygame.USEREVENT+1, 30000, []
SHOOT, t, trail = pygame.USEREVENT+2, 2000, []
#move speed
MOVE_SPEED = 6

#start point enemy
STARTx = 0
STARTy = 0


# gamespeed
DIFICULT = 10

#laser tower cost
LAZCOST = 15
#short tower cost
SHORTCOST = 10

# numbers of finished enemies
HEALTH = 1

#lazer color
lazcol = (150,150,150)

#colours
BACKGROUND_COLOR = "#004400"
PLATFORM_COLOR = "#FF6262"
PLATFORM_COLOR1 = "#006262"

#images for game
all_images = pygame.image.load(os.path.join("data","babytux.png"),)
all_t = pygame.image.load(os.path.join("data","mario.png"))
all_t1 = pygame.image.load(os.path.join("data","laztow.png"))

# way where enemy go "-"  
level = [
       "   ---              ",
       "   - -              ",
       "   - -              ",
       "s--- - ------------f",
       "     - -            ",
       "     - -            ",
       "     - -            ",
       "     - -            ",
       "     - -            ",
       "     ---            ",
       "                    ",
       ]


#nubers of platform
NUMBERS_HEIGHT = len(level)
NUMBERS_WIDTH = len(level[0])


#size of platform
PLATFORM_WIDTH = WIN_WIDTH/NUMBERS_WIDTH
PLATFORM_HEIGHT = WIN_HEIGHT/NUMBERS_HEIGHT
