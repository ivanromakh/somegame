import pygame
import settings

def persent(screen):
    x = 50
    
    text = "IVANATION PRODUCTION"
    y = len(text)
    
    screen.fill((0,0,0))
    introduce = pygame.font.SysFont("monospace", x)
    text1 = introduce.render(text, 1, (100, 100, 100))
    screen.blit(text1, ((WIN_WIDTH-x*y*4/6)/2, ((WIN_HEIGHT-x)/2)))
    pygame.display.flip()                         # flip the screen 30 times a second  
    pygame.time.delay(1)

    time.delay(2000)

    text = "PRESENT"
    y = len(text)
    
    screen.fill((0,0,0))
    text1 = introduce.render(text, 1, (100, 100, 100))
    screen.blit(text1, ((WIN_WIDTH-x*y*4/6)/2, ((WIN_HEIGHT-x)/2)))
    pygame.display.flip()          # flip the screen 30 times a second  
    pygame.time.delay(1)

    time.delay(2000)
    text = "TOWER DEFFENCE"
    y = len(text)
    
    screen.fill((0,0,0))
    text1 = introduce.render(text, 1, (100, 100, 100))
    screen.blit(text1, ((WIN_WIDTH-x*y*4/6)/2, ((WIN_HEIGHT-x)/2)))
    pygame.display.flip()          # flip the screen 30 times a second  
    pygame.time.delay(1)
    time.delay(2000)
    
    
def drawtext(screen, hel, scope, timer, number):
    mytext = pygame.font.SysFont("monospace", 15)
    text = mytext.render("FPS "+str(timer.get_fps()), 1, (10, 10, 10))
    screen.blit(text, (5, 0))
    text = mytext.render("Health"+str(hel), 1, (10, 10, 10))
    screen.blit(text, (5, 15))
    text = mytext.render("Scope"+str(scope), 1, (10, 10, 10))
    screen.blit(text, (5, 30))
    text = mytext.render("Enemy "+str(number), 1, (10, 10, 10))
    screen.blit(text, (5, 45))
