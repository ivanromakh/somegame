import pygame
import os
import sys
from settings import *
from pygame import *
from tower import create_tower
from enemyjourny import Enemy, Enemy_way, left_border
from menu import Menu, mennu
from pygame.locals import *
from MyButtons import*
from present import persent, drawtext 

        # when pause button touch 

# pause start 
def startpause(p, pausa):
    pos = pygame.mouse.get_pos()
    if pausa.pressed(pos):
        p = True
    return p

# start create tower mode
def createmode(p, pausa, laz_tow, sh_tow, tow_type, pos, create):
    create = 0
    for e in pygame.event.get():
        if e.type == pygame.MOUSEBUTTONUP:     
            if pausa.pressed(pos):
                p = False
            elif laz_tow.pressed(pos):
                tow_type = 0
            elif sh_tow.pressed(pos):
                tow_type = 1
            else:
                create = 1
                print pos
    return (p, tow_type, create)

# create tower
def createtow(screen, towers, scope, tow_type, pos, create):
    if create == 1:
        upgraded = 0
        for tow in towers:
            if scope>=tow.cost:
                if pos[0]>=tow.rect.x and pos[0]<=tow.rect.x + PLATFORM_WIDTH and pos[1]>=tow.rect.y and pos[1]<=tow.rect.y + PLATFORM_WIDTH:
                    x = tow.tow_upgrade()
                    if x == True:
                        scope = scope - tow.cost
                    upgraded = 1    
        if upgraded == 0:
            tow = create_tower(screen, tow_type, True)
            if tow !=0:
                if scope>=tow.cost:
                    scope = scope - tow.cost
                    return (tow, scope)
                else:
                    tow.kill()
    return 0,scope                

# if mouse under object
def mousecatch(screen, towers, all_enemies, pos):
    for tow in towers:
        if pos[0]>=tow.rect.x and pos[0]<=tow.rect.x + PLATFORM_WIDTH and pos[1]>=tow.rect.y and pos[1]<=tow.rect.y + PLATFORM_WIDTH:
            back = pygame.rect.Rect((pos[0]+10,pos[1]), (150, 60))
            pygame.draw.rect(screen, (0,250,0), back)
            health = pygame.font.SysFont("monospace", 20)
            over = health.render(str(tow.name), 1, (10, 10, 10))
            screen.blit(over, ((pos[0]+10, pos[1])))
            over = health.render("damage "+str(tow.damage), 1, (10, 10, 10))
            screen.blit(over, ((pos[0]+10, pos[1]+15)))
            over = health.render("radius "+str(tow.radius), 1, (10, 10, 10))
            screen.blit(over, ((pos[0]+10, pos[1]+30)))
            
        pygame.draw.circle(screen, (250,0,0), tow.center, tow.radius, 1)   
            
    for enemy in all_enemies:
        if pos[0]>=enemy.rect.x and pos[0]<=enemy.rect.x + PLATFORM_WIDTH and pos[1]>=enemy.rect.y and pos[1]<=enemy.rect.y + PLATFORM_WIDTH:
            back = pygame.rect.Rect(pos, (150, 60))
            pygame.draw.rect(screen, (150,150,150), back)
            health = pygame.font.SysFont("monospace", 20)
            over = health.render(enemy.name, 1, (10, 10, 10))
            screen.blit(over, ((pos[0]+10,pos[1])))
            over = health.render("level  "+str(enemy.thistype+1), 1, (10, 10, 10))
            screen.blit(over, ((pos[0]+10,pos[1]+15)))
            over = health.render("health "+str(enemy.health), 1, (10, 10, 10))
            screen.blit(over, ((pos[0]+10,pos[1]+30)))
            
        
def main():
    pygame.init()
    screen = pygame.display.set_mode(DISPLAY) 
    pygame.display.set_caption("Tower deffence")
    bg = Surface((WIN_WIDTH,WIN_HEIGHT))
    #persent(screen) 
    mennu()
    # event for firefare and enemyrate
    pygame.time.set_timer(SHOOT, t)
    pygame.time.set_timer(ENEMYRATE, t1/DIFICULT)

    #display    
    screen = pygame.display.set_mode(DISPLAY) 
    pygame.display.set_caption("Tower deffence")
    
    bg = Surface((WIN_WIDTH,WIN_HEIGHT))
    
    bg.fill(Color(BACKGROUND_COLOR))

    #groups of enemies towers and borders
    enemyway = pygame.sprite.Group()
    towers = pygame.sprite.Group()
    borders = pygame.sprite.Group()
    all_enemies = pygame.sprite.Group()
    Enemy.groups = all_enemies
    
    #numbers of enemy
    number = 0
    create = 0
    #buttons
    sh_tow = createbuttons()
    laz_tow = createbuttons()
    pausa = createbuttons()
    
    #clock
    timer = pygame.time.Clock()
    
    # tower type lazer or short
    tow_type = -1
    
    #generating borders and ways
    x=y=0 
    for row in level: 
        for col in row: 
            if col == "-":
                way = Enemy_way(x,y)
                enemyway.add(way)
                            
                border = left_border(x,y)
                borders.add(border)
            if col == "s":
                STARTx = x/PLATFORM_WIDTH
                STARTy = y/PLATFORM_HEIGHT
                way = Enemy_way(x,y)
                border = left_border(x,y)
                enemyway.add(way)
                borders.add(border)
            if col == 'f':
                way = Enemy_way(x,y)
                enemyway.add(way)
                border = left_border(x,y)
                borders.add(border)
            x += PLATFORM_WIDTH
        y += PLATFORM_HEIGHT    
        x = 0                   
    x=0
    scope = 10
    hel = HEALTH

    #pausa
    p = False
    
    # game began
    game = True
    #dif
    dif = DIFICULT
    diff = 0
    upgraded = 0
    en_id = 0
    limit = 20

    while game:
        #update some objects
        
        pygame.display.update() 
        enemyway.update()
        borders.update()

        screen.fill((100,100,100))
        
        #draw some objects  
        borders.draw(screen)
        enemyway.draw(screen)
        towers.draw(screen)
        all_enemies.draw(screen)
        for enemy in all_enemies:
            enemy.paint_health(screen)
        
        #draw enemy 
        all_enemies.update
        number =1
        for enemy in all_enemies:
            number +=1
            enemy.update(borders)
            if enemy.finish == 1:
                enemy.kill()
                hel-=1
                if hel==0:
                    game = False           
        
        
        #tower and bullets
        for e in pygame.event.get():
            # exit
            if e.type == QUIT:
                raise SystemExit, "QUIT"
            # create tower
            if e.type == pygame.MOUSEBUTTONUP:
                print "ss"
                p = startpause(p, pausa)
                while p == True:

                    # mouse position
                    pos = pygame.mouse.get_pos()

                    # set create mode 
                    (p, tow_type, create) = createmode(p, pausa, laz_tow, sh_tow, tow_type, pos, create)

                    #create tower
                    (tow, scope) = createtow(screen, towers, scope, tow_type, pos, create) 
                    
                    if tow!=0:    
                        towers.add(tow)
                        
                    screen.fill((100,100,100))

                    #draw all objects  
                    borders.draw(screen)
                    enemyway.draw(screen)
                    towers.draw(screen)
                    all_enemies.draw(screen)

                    drawtext(screen, hel,scope, timer, number)

                    for enemy in all_enemies:
                        enemy.paint_health(screen)
                    
                    #draw buttons
                    update_display(screen, sh_tow, 10, LAZCOST)
                    update_display(screen, laz_tow, 45, SHORTCOST)
                    update_display(screen, pausa, 80, "PAUSA")
                    
                    # if mouse under tower or enemy
                    mousecatch(screen, towers, all_enemies, pos)
                    pygame.display.flip()

            # shotting in traped enemy                
            if e.type == SHOOT:
                for tow in towers:
                    trapped_enemy = pygame.sprite.spritecollide(tow, all_enemies, False, pygame.sprite.collide_circle) 
                    if trapped_enemy != []:
                        x = trapped_enemy[0].id
                        ens = trapped_enemy[0]
                        for en in trapped_enemy:
                            if en.id<x:
                                ens = en
                                x = en.id
                        tow.update(ens)
                    
            # create enemy    
            if e.type == ENEMYRATE:
                if number<BLUE_CREEP:
                    pygame.time.set_timer(ENEMYRATE, t1/dif)
                    Enemy(STARTx, STARTy, BLUE, en_id)
                    dif+=1
                    en_id+=1  
                   
                if number>=BLUE_CREEP and number<YELLOW_CREEP:
                    pygame.time.set_timer(ENEMYRATE, t1/dif)
                    Enemy(STARTx, STARTy, YELLOW, en_id)
                    dif+=1
                    en_id+=1  
                if number>=YELLOW_CREEP and number<=30:
                    pygame.time.set_timer(ENEMYRATE, t1/dif)
                    Enemy(STARTx, STARTy, RED, en_id)
                    en_id+=1  
                   
                    
        for tow in towers:                
            scopes = tow.shotting(screen, all_enemies)
            if scopes >0:
                limit-=1
            scope+= scopes    

        #text on monitor    
        timer.tick(40)
        
        #draw the text on left corner
        drawtext(screen, hel,scope, timer, number)
    
        update_display(screen, sh_tow, 10, LAZCOST)
        update_display(screen, laz_tow, 45, SHORTCOST)
        update_display(screen, pausa, 80, "PAUSA")

        #re draw display
        pygame.display.flip()          # flip the screen 30 times a second  
        if limit == 0:
            game = False
    if limit == 0:
        #finish 
        screen.fill((100,100,100))
        health = pygame.font.SysFont("monospace", 40)
        over = health.render("GAME OVER", 1, (10, 10, 10))
        screen.blit(over, (WIN_WIDTH/2-100,WIN_HEIGHT/2-20))
        over = health.render("YOU WIN", 1, (10, 10, 10))
        screen.blit(over, (WIN_WIDTH/2-100,WIN_HEIGHT/2+25))
            
        pygame.display.flip()
        pygame.time.delay(1000)
    else:   
        #finish 
        screen.fill((100,100,100))
        health = pygame.font.SysFont("monospace", 40)
        over = health.render("GAME OVER", 1, (10, 10, 10))
        screen.blit(over, (WIN_WIDTH/2-100,WIN_HEIGHT/2-20))
        over = health.render("YOU LOSE", 1, (10, 10, 10))
        screen.blit(over, (WIN_WIDTH/2-100,WIN_HEIGHT/2+25))
            
        pygame.display.flip()
        pygame.time.delay(1000)

# main fuction                
if __name__ == "__main__":
    main()
    
