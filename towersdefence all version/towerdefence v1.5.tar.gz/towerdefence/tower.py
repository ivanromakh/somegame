import pygame
import os
from pygame import *
from pygame.time import *
from mygame4 import level
from settings import*
import math

class MyTower(sprite.Sprite):
    image = []
    def __init__(self, x, y):
        sprite.Sprite.__init__(self)
        self.xvel = 0
        self.image = MyTower.image[0]
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.bullets = pygame.sprite.Group()
        self.rect.y = y
        self.radius = 100
    def draw(self, screen): 
        screen.blit(self.image, (self.rect.x,self.rect.y))
    def update(self, enemies, screen):
        catch = 0
        trapped_enemy = pygame.sprite.spritecollide(self, enemies, False, pygame.sprite.collide_circle)
        for myenemy in trapped_enemy:
            if catch != 1:
                for e in pygame.event.get():
                    if e.type == SHOOT:
                        print "ss", catch
                        shoot = Bullets(myenemy.rect, self.rect)
                        shoot.rotate()
                        self.bullets.add(shoot)
                        catch = 1
                        
            self.bullets.draw(screen)
            self.bullets.update(myenemy)            
            
def create_tower(screen):
    positions = mouse.get_pos()
    MyTower.image.append(pygame.image.load(os.path.join("data","tower.png")))
    row= positions[0]/PLATFORM_WIDTH
    x = row*PLATFORM_WIDTH
    col= positions[1]/ PLATFORM_HEIGHT
    y =col* PLATFORM_HEIGHT
    # if not on enemy way
    if level[col][row] != '-':
        tower = MyTower(x, y)
    # center of tower
    center = (x+PLATFORM_WIDTH/2,y+PLATFORM_HEIGHT/2)
    return tower

class Bullets(sprite.Sprite):
    def __init__(self, enemy_cord, tower_cord):
        sprite.Sprite.__init__(self)
        self.xvel = (VELOCITY*(enemy_cord.x - tower_cord.x))/(math.fabs(enemy_cord.x - tower_cord.x)+math.fabs(enemy_cord.y - tower_cord.y))
        self.yvel = (VELOCITY*(enemy_cord.y - tower_cord.y))/(math.fabs(enemy_cord.x - tower_cord.x)+math.fabs(enemy_cord.y - tower_cord.y))
        self.enemy_cord = enemy_cord
        self.tower_cord = tower_cord
        self.imageMaster = pygame.image.load(os.path.join("data","bullet.png"))
        self.image = self.imageMaster
        self.rect = self.image.get_rect()
        self.angle = (math.atan((self.enemy_cord.y - self.tower_cord.y)/(self.enemy_cord.x - self.tower_cord.x))*180)/(math.pi*(-1))
        
        self.rect.x = tower_cord.x 
        self.rect.y = tower_cord.y
        
    def update(self, myenemy):
        self.rect.x = self.rect.x + self.xvel
        self.rect.y = self.rect.y + self.yvel
        if sprite.collide_rect(self, myenemy):
            myenemy.kill()
            self.kill()
    def rotate(self):
        oldCenter = self.rect.center
        self.image = pygame.transform.rotate(self.imageMaster, self.angle)
        self.rect = self.image.get_rect()
        self.rect.center = oldCenter
        
    def draw(self, screen):
        screen.blit(self.image, (self.rect.x,self.rect.y))
