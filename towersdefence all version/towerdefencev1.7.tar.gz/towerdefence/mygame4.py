import pygame
import os
from settings import *
from pygame import *
from pygame.time import *
from tower import*
from enemyjourny import Enemy, Enemy_way, left_border
from menu import*


def mennu():
    surface = pygame.display.set_mode((WIN_WIDTH,WIN_HEIGHT)) 
    surface.fill((51,51,51))
    menu = Menu()#necessary
    menu.init(['Start','Options','Quit'], surface)#necessary
    menu.draw()#necessary
    pygame.key.set_repeat(199,69)#(delay,interval)
    pygame.display.update()
    menus = True
    while menus:
        for event in pygame.event.get():
            if event.type == KEYDOWN:
                if event.key == K_UP:
                    menu.draw(-1) #here is the Menu class function
                if event.key == K_DOWN:
                    menu.draw(1) #here is the Menu class function
                if event.key == K_RETURN:
                    if menu.get_position() == 2:#here is the Menu class function
                        pygame.display.quit()
                        sys.exit()
                    if menu.get_position() == 0:
                        menus = False                        
                if event.key == K_ESCAPE:
                    pygame.display.quit()
                    sys.exit()
                pygame.display.update()
            elif event.type == QUIT:
                pygame.display.quit()
                sys.exit()
        pygame.time.wait(8)

def main():
    pygame.init() 
    Enemy.image.append(pygame.image.load(os.path.join("data","babytux.png")))
    mennu()
    # 60 frame in second
    timer = pygame.time.Clock()
    timer.tick(1)
    x = 1000
    time.set_timer(SHOOT, t)
    time.set_timer(ENEMYRATE, t1)
    screen = pygame.display.set_mode(DISPLAY) 
    pygame.display.set_caption("Tower deffence") 
    bg = Surface((WIN_WIDTH,WIN_HEIGHT))
                                         
    bg.fill(Color(BACKGROUND_COLOR))     
    screen.blit(bg, (0,0)) 
    pygame.display.update()

    #way for enemy
    enemyway = pygame.sprite.Group()
    towers = pygame.sprite.Group()
    borders = pygame.sprite.Group()
    all_enemies = pygame.sprite.Group()
    
    bullets = pygame.sprite.Group()
    
    Enemy.groups = all_enemies
    x=y=0 
    for row in level: 
               for col in row: 
                      if col == "-":
                             way = Enemy_way(x,y)
                             way.draw(screen)
                             enemyway.add(way)
                             
                             border = left_border(x,y)
                             borders.add(border)
                      if col == "s":
                             STARTx = x/PLATFORM_WIDTH
                             STARTy = y/PLATFORM_HEIGHT
                             way = Enemy_way(x,y)
                             border = left_border(x,y)
                             enemyway.add(way)
                             borders.add(border)
                      x += PLATFORM_WIDTH 
               y += PLATFORM_HEIGHT    
               x = 0                   
    
     
    
    while 1: 
        for e in pygame.event.get(): 
            if e.type == QUIT:
                raise SystemExit, "QUIT"
            if e.type == pygame.MOUSEBUTTONUP:
                tow = create_tower(screen)
                towers.add(tow)
            if e.type == ENEMYRATE:
                Enemy(STARTx, STARTy)
                
        # display 
        pygame.display.update()     
        screen.fill((255,0,0))

        #draw ways
        enemyway.update()
        enemyway.draw(screen)
        
        #draw boders  
        borders.draw(screen)
        borders.update()
        #draw enemy 
        all_enemies.update(borders)        
        
        
        #tower and bullets
        for e in pygame.event.get():
            if e.type == SHOOT:
                for tow in towers:
                    trapped_enemy = pygame.sprite.spritecollide(tow, all_enemies, False, pygame.sprite.collide_circle)
                    catch = 0    
                    for myenemy in trapped_enemy:
                        if catch !=1:
                            tow.update(myenemy)
                            catch = 1

        for tow in towers:                
            tow.shotting(screen)        
        towers.draw(screen)
        pygame.time.delay(5)
        all_enemies.draw(screen)
        pygame.display.flip()          # flip the screen 30 times a second  
        
                
if __name__ == "__main__":
    main()
    
