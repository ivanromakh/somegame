import pygame
from pygame import *
from pygame.time import *
from tower import*
from enemyjourny import Enemy, Enemy_way, left_border




#display
WIN_WIDTH = 800 
WIN_HEIGHT = 500 
DISPLAY = (WIN_WIDTH, WIN_HEIGHT)

#move speed
MOVE_SPEED = 1
#start point
STARTx = 0
STARTy = 0
#nubers of platform
NUMBERS_WIDTH = 25
NUMBERS_HEIGHT = 20
#size of enemy
ENEMY_WIDTH = WIN_WIDTH/(NUMBERS_WIDTH*2)
ENEMY_HEIGHT = WIN_HEIGHT/(NUMBERS_HEIGHT*2)


#size of platform
PLATFORM_WIDTH = WIN_WIDTH/NUMBERS_WIDTH
PLATFORM_HEIGHT = WIN_HEIGHT/NUMBERS_HEIGHT

#colours
BACKGROUND_COLOR = "#004400"
PLATFORM_COLOR = "#FF6262"
PLATFORM_COLOR1 = "#006262"


# way where enemy go "-"  
level = [
       "                         ",
       "                         ",
       "                         ",
       "                         ",
       "                         ",
       "                         ",
       "                         ",
       "           ----          ",
       "           -  -   -------",
       "s-- ------ -  -   -      ",
       "  - -    ---  -----      ",
       "  ---                    ",
       "                         ",
       "                         ",
       "                         ",
       "                         ",
       "                         ",
       "                         ",
       "                         ",
       "                         "]

def main():
    pygame.init() 

    # 60 frame in second
    timer = pygame.time.Clock()
    timer.tick(10)
    
    screen = pygame.display.set_mode(DISPLAY) 
    pygame.display.set_caption("Super Mario Boy") 
    bg = Surface((WIN_WIDTH,WIN_HEIGHT)) 
                                         
    bg.fill(Color(BACKGROUND_COLOR))     
    screen.blit(bg, (0,0)) 
    pygame.display.update()

    #way for enemy
    enemyway = pygame.sprite.Group()
    towers = pygame.sprite.Group()
    borders = pygame.sprite.Group()
    
    x=y=0 
    for row in level: 
               for col in row: 
                      if col == "-":
                             way = Enemy_way(x,y)
                             way.draw(screen)
                             enemyway.add(way)
                             
                             border = left_border(x,y)
                             borders.add(border)
                      if col == "s":
                             STARTx = x/PLATFORM_WIDTH
                             STARTy = y/PLATFORM_HEIGHT
                             print "Start x ", STARTx , " y ", STARTy
                             way = Enemy_way(x,y)
                             border = left_border(x,y)
                             enemyway.add(way)
                             borders.add(border)
                      x += PLATFORM_WIDTH 
               y += PLATFORM_HEIGHT    
               x = 0                   
    print "Start x ", STARTx , " y ", STARTy
    myenemy = Enemy(STARTx, STARTy)           
    while 1: 
        for e in pygame.event.get(): 
            if e.type == QUIT:
                raise SystemExit, "QUIT"
            if e.type == pygame.MOUSEBUTTONUP:
                print "dsf"
                tow = create_tower(screen)
                towers.add(tow) 

        # display 
        pygame.display.update()     
        screen.fill((255,0,0))

        #draw ways
        enemyway.update()
        enemyway.draw(screen)
        
        #draw boders  
        borders.draw(screen)
        borders.update()

        #draw enemy 
        myenemy.update(borders)        
        myenemy.draw(screen)

        #draw towers 
        towers.update()
        towers.draw(screen)

        #speed of the game 
        time.delay(10)







                
if __name__ == "__main__":
    main()
    
