import pygame
from pygame import *
from pygame.time import *
from mygame4 import level

#display
WIN_WIDTH = 800 
WIN_HEIGHT = 500 
DISPLAY = (WIN_WIDTH, WIN_HEIGHT)

#move speed
MOVE_SPEED = 1
#start point
STARTx = 0
STARTy = 0
#nubers of platform
NUMBERS_WIDTH = 25
NUMBERS_HEIGHT = 20

#size of platform
PLATFORM_WIDTH = WIN_WIDTH/NUMBERS_WIDTH
PLATFORM_HEIGHT = WIN_HEIGHT/NUMBERS_HEIGHT

#colours
BACKGROUND_COLOR = "#004400"
PLATFORM_COLOR = "#FF6262"
PLATFORM_COLOR1 = "#006262"




class MyTower(sprite.Sprite):
    def __init__(self, x, y, r):
        sprite.Sprite.__init__(self)
        self.startX = x
        self.xvel = 0
        self.startY = y
        self.image = Surface((PLATFORM_WIDTH,PLATFORM_HEIGHT))
        self.image.fill((0,255,0,0))
        self.rect = Rect(self.startX, self.startY, PLATFORM_WIDTH,PLATFORM_HEIGHT) 
        print "MMMx ", x, " y ", y
    def draw(self, screen): 
        screen.blit(self.image, (self.rect.x,self.rect.y))

        
def create_tower(screen):
    positions = mouse.get_pos()
    print positions
    row= positions[0]/PLATFORM_WIDTH
    x = row*PLATFORM_WIDTH
    col= positions[1]/ PLATFORM_HEIGHT
    y =col* PLATFORM_HEIGHT
    radius = 100
    print "w", row, "r", col
    # if not on enemy way
    if level[col][row] != '-':
        tower = MyTower(x, y, radius)
    # center of tower
    center = (x+PLATFORM_WIDTH/2,y+PLATFORM_HEIGHT/2)
    return tower
    
