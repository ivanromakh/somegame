import pygame
import os
from pygame import *
from pygame.time import *
from mygame4 import level
from settings import*
from mygame4 import all_bullets

class MyTower(sprite.Sprite):
    image = []
    def __init__(self, x, y):
        sprite.Sprite.__init__(self)
        self.xvel = 0
        self.image = MyTower.image[0]
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.radius = 100
        self.firerite = 1000
        print "MMMx ", x, " y ", y
    def draw(self, screen): 
        screen.blit(self.image, (self.rect.x,self.rect.y))
    def update(self, enemies, screen):
        trapped_enemy = pygame.sprite.spritecollide(self, enemies, False, pygame.sprite.collide_circle)
        for myenemy in trapped_enemy:
            for e in pygame.event.get():
                if e.type == SHOOT:
                    shoot = Bullets(myenemy.rect, self.rect)
                    all_bullets.add(shoot)
            all_bullets.draw(screen)
            all_bullets.update()
            
            
    def shoot(self):
        print "1 second leff"
            
            
def create_tower(screen):
    positions = mouse.get_pos()
    MyTower.image.append(pygame.image.load(os.path.join("data","tower.png")))
    print positions
    row= positions[0]/PLATFORM_WIDTH
    x = row*PLATFORM_WIDTH
    col= positions[1]/ PLATFORM_HEIGHT
    y =col* PLATFORM_HEIGHT
    print "w", row, "r", col
    # if not on enemy way
    if level[col][row] != '-':
    
        tower = MyTower(x, y)
    # center of tower
    center = (x+PLATFORM_WIDTH/2,y+PLATFORM_HEIGHT/2)
    return tower

class Bullets(sprite.Sprite):
    def __init__(self, enemy_cord, tower_cord):
        sprite.Sprite.__init__(self)
        self.xvel = 5
        self.yvel = 1
        self.enemy_cord = enemy_cord
        self.image = pygame.image.load(os.path.join("data","bullet.png"))
        self.rect = self.image.get_rect()
        self.rect.x = tower_cord.x 
        self.rect.y = tower_cord.y
    def update(self):
        self.rect.x = self.rect.x + self.xvel
    def draw(self, screen):
        screen.blit(self.image, (self.rect.x,self.rect.y))
