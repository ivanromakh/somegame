import pygame

#display
WIN_WIDTH = 800 
WIN_HEIGHT = 500 
DISPLAY = (WIN_WIDTH, WIN_HEIGHT)



SHOOT, t, trail = pygame.USEREVENT+1, 250, []
#move speed
MOVE_SPEED = 1
#start point
STARTx = 0
STARTy = 0
#nubers of platform
NUMBERS_WIDTH = 10
NUMBERS_HEIGHT = 10

#size of platform
PLATFORM_WIDTH = WIN_WIDTH/NUMBERS_WIDTH
PLATFORM_HEIGHT = WIN_HEIGHT/NUMBERS_HEIGHT

#colours
BACKGROUND_COLOR = "#004400"
PLATFORM_COLOR = "#FF6262"
PLATFORM_COLOR1 = "#006262"

# way where enemy go "-"  
level = [
       "               ",
       "               ",
       "   -----       ",
       "s---   ----    ",
       "               ",
       "               ",
       "               ",
       "               ",
       ]




