import pygame
from pygame import *
from pygame.time import *
from mygame4 import level
from settings import*

class MyTower(sprite.Sprite):
    def __init__(self, x, y, r):
        sprite.Sprite.__init__(self)
        self.startX = x
        self.xvel = 0
        self.startY = y
        self.image = Surface((PLATFORM_WIDTH,PLATFORM_HEIGHT))
        self.image.fill((0,255,0,0))
        self.rect = Rect(self.startX, self.startY, PLATFORM_WIDTH,PLATFORM_HEIGHT) 
        print "MMMx ", x, " y ", y
    def draw(self, screen): 
        screen.blit(self.image, (self.rect.x,self.rect.y))
        
def create_tower(screen):
    positions = mouse.get_pos()
    print positions
    row= positions[0]/PLATFORM_WIDTH
    x = row*PLATFORM_WIDTH
    col= positions[1]/ PLATFORM_HEIGHT
    y =col* PLATFORM_HEIGHT
    radius = 100
    print "w", row, "r", col
    # if not on enemy way
    if level[col][row] != '-':
        tower = MyTower(x, y, radius)
    # center of tower
    center = (x+PLATFORM_WIDTH/2,y+PLATFORM_HEIGHT/2)
    return tower
    
