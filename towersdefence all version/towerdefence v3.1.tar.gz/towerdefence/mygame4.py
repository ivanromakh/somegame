import pygame
import os
import sys
from settings import *
from pygame import *
from tower import MyTower, create_tower
from enemyjourny import Enemy, Enemy_way, left_border
from menu import Menu, mennu
from pygame.locals import *
from Button import MyButtons



def main():
    pygame.init() 
    Enemy.image.append(all_images)
    mennu()
    # 60 frame in second
    timer = pygame.time.Clock()
    
    # event for firefare and enemyrate
    pygame.time.set_timer(SHOOT, 500)
    pygame.time.set_timer(ENEMYRATE, t1/DIFICULT)

    #display    
    screen = pygame.display.set_mode(DISPLAY) 
    pygame.display.set_caption("Tower deffence") 
    bg = Surface((WIN_WIDTH,WIN_HEIGHT))
    
    bg.fill(Color(BACKGROUND_COLOR))

    
    #groups of enemies towers and borders
    enemyway = pygame.sprite.Group()
    towers = pygame.sprite.Group()
    borders = pygame.sprite.Group()
    all_enemies = pygame.sprite.Group()
    Enemy.groups = all_enemies
    #numbers of enemy
    number = 0
    
    
    #generating borders and ways
    x=y=0 
    for row in level: 
        for col in row: 
            if col == "-":
                way = Enemy_way(x,y)
                way.draw(screen)
                enemyway.add(way)
                            
                border = left_border(x,y)
                borders.add(border)
            if col == "s":
                STARTx = x/PLATFORM_WIDTH
                STARTy = y/PLATFORM_HEIGHT
                way = Enemy_way(x,y)
                border = left_border(x,y)
                enemyway.add(way)
                borders.add(border)
            if col == 'f':
                way = Enemy_way(x,y)
                way.draw(screen)
                enemyway.add(way)
                border = left_border(x,y)
                borders.add(border)
            x += PLATFORM_WIDTH
        y += PLATFORM_HEIGHT    
        x = 0                   
    x=0
    scope = 10
    dif = DIFICULT
    hel = HEALTH
    Enemy(STARTx, STARTy)
    # game began
    game = True
    while game:
        #update some objects
        pygame.display.update() 
        enemyway.update()
        borders.update()

        screen.fill((100,100,100))
        
        #draw some objects  
        borders.draw(screen)
        enemyway.draw(screen)
        towers.draw(screen)
        all_enemies.draw(screen)
        
        #draw enemy 
        all_enemies.update
        number =1
        for enemy in all_enemies:
            number +=1
            enemy.update(borders)
            if enemy.finish == 1:
                enemy.kill()
                hel-=1
                if hel==0:
                    game = False
        #tower and bullets
        for e in pygame.event.get():
            # exit
            if e.type == QUIT:
                raise SystemExit, "QUIT"
            # create tower
            if e.type == pygame.MOUSEBUTTONUP:
                if scope>=10: 
                    tow = create_tower(screen)
                    towers.add(tow)
                    scope = scope -10
            if e.type == SHOOT:
                x+=1
                for tow in towers:
                    trapped_enemy = pygame.sprite.spritecollide(tow, all_enemies, False, pygame.sprite.collide_circle)
                    catch = 0    
                    for myenemy in trapped_enemy:
                        if catch !=1:
                            tow.update(myenemy)
                            catch = 1
            # create enemy    
            if e.type == ENEMYRATE:
                pygame.time.set_timer(ENEMYRATE, t1/dif)
                dif +=1
                Enemy(STARTx, STARTy)
            
        for tow in towers:                
            scope = scope + tow.shotting(screen, all_enemies)
        MyCOINS = pygame.font.SysFont("monospace", 15)
        health = pygame.font.SysFont("monospace", 15)
        timer.tick(100)
        text3 = MyCOINS.render("FPS "+str(timer.get_fps()), 1, (10, 10, 10))
        text2 = health.render("Health"+str(hel), 1, (10, 10, 10))
        text1 = MyCOINS.render("Scope"+str(scope), 1, (10, 10, 10))
        screen.blit(text1, (WIN_WIDTH-100, 0))
        screen.blit(text2, (WIN_WIDTH-100, 15))
        screen.blit(text3, (WIN_WIDTH-100, 30))
        text3 = MyCOINS.render("Enemy "+str(number), 1, (10, 10, 10))
        
        screen.blit(text3, (WIN_WIDTH-100, 45))
        
        pygame.display.flip()          # flip the screen 30 times a second  
        pygame.time.delay(1)
        
    #finish 
    screen.fill((100,100,100))
    health = pygame.font.SysFont("monospace", 40)
    over = health.render("GAME OVER", 1, (10, 10, 10))
    screen.blit(over, (WIN_WIDTH/2-100,WIN_HEIGHT/2-20))
    over = health.render("YOU LOSE", 1, (10, 10, 10))
    screen.blit(over, (WIN_WIDTH/2-100,WIN_HEIGHT/2+25))
            
    pygame.display.flip()
    pygame.time.delay(1000)

# main fuction                
if __name__ == "__main__":
    main()
    
