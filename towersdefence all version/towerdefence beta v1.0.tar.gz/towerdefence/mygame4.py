import pygame
import os
import sys
from settings import *
from pygame import *
from tower import create_tower
from enemyjourny import Enemy, Enemy_way, left_border
from menu import Menu, mennu
from pygame.locals import *
from MyButtons import*



def main():
    pygame.init()
    Enemy.images.append(all_images)
    mennu()
    # 60 frame in second
    timer = pygame.time.Clock()

    # event for firefare and enemyrate
    pygame.time.set_timer(SHOOT, t)
    pygame.time.set_timer(ENEMYRATE, t1/DIFICULT)

    #display    
    screen = pygame.display.set_mode(DISPLAY) 
    pygame.display.set_caption("Tower deffence")
    
    bg = Surface((WIN_WIDTH,WIN_HEIGHT))
    
    bg.fill(Color(BACKGROUND_COLOR))

    #groups of enemies towers and borders
    enemyway = pygame.sprite.Group()
    towers = pygame.sprite.Group()
    borders = pygame.sprite.Group()
    all_enemies = pygame.sprite.Group()
    Enemy.groups = all_enemies
    #numbers of enemy
    number = 0

    #buttons
    sh_tow = createbuttons()
    laz_tow = createbuttons()

    # tower type lazer or short
    tow_type = 0
    
    #generating borders and ways
    x=y=0 
    for row in level: 
        for col in row: 
            if col == "-":
                way = Enemy_way(x,y)
                way.draw(screen)
                enemyway.add(way)
                            
                border = left_border(x,y)
                borders.add(border)
            if col == "s":
                STARTx = x/PLATFORM_WIDTH
                STARTy = y/PLATFORM_HEIGHT
                way = Enemy_way(x,y)
                border = left_border(x,y)
                enemyway.add(way)
                borders.add(border)
            if col == 'f':
                way = Enemy_way(x,y)
                way.draw(screen)
                enemyway.add(way)
                border = left_border(x,y)
                borders.add(border)
            x += PLATFORM_WIDTH
        y += PLATFORM_HEIGHT    
        x = 0                   
    x=0
    scope = 10
    hel = HEALTH

    # game began
    game = True
    dif = DIFICULT
    diff = 0

    while game:
        #update some objects
        pygame.display.update() 
        enemyway.update()
        borders.update()

        screen.fill((100,100,100))
        
        #draw some objects  
        borders.draw(screen)
        enemyway.draw(screen)
        towers.draw(screen)
        all_enemies.draw(screen)
        for enemy in all_enemies:
            enemy.paint_health(screen)
        
        #draw enemy 
        all_enemies.update
        number =1
        for enemy in all_enemies:
            number +=1
            enemy.update(borders)
            if enemy.finish == 1:
                enemy.kill()
                hel-=1
                if hel==0:
                    game = False
        
        
        #tower and bullets
        for e in pygame.event.get():
            # exit
            if e.type == QUIT:
                raise SystemExit, "QUIT"
            # create tower
            if e.type == pygame.MOUSEBUTTONUP:
                pos = pygame.mouse.get_pos()
                if laz_tow.pressed(pos):
                    tow_type = 0
                elif sh_tow.pressed(pygame.mouse.get_pos(pos)):
                    tow_type = 1
                else:    
                    tow = create_tower(screen, tow_type, True)
                    if tow !=0:
                        if scope>=tow.cost:
                            towers.add(tow)
                            scope = scope - tow.cost
                        else:
                            tow.kill()
            # shotting in traped enemy                
            if e.type == SHOOT:
                x+=1
                for tow in towers:
                    trapped_enemy = pygame.sprite.spritecollide(tow, all_enemies, False, pygame.sprite.collide_circle)
                    catch = 0    
                    for myenemy in trapped_enemy:
                        if catch !=1:
                            tow.update(myenemy)
                            catch = 1
            # create enemy    
            if e.type == ENEMYRATE:
                if number<BLUE_CREEP:
                    pygame.time.set_timer(ENEMYRATE, t1/dif)
                    Enemy(STARTx, STARTy, BLUE)
                    dif+=1
                   
                if number>=BLUE_CREEP and number<YELLOW_CREEP:
                    pygame.time.set_timer(ENEMYRATE, t1/dif)
                    print "ss"    
                    Enemy(STARTx, STARTy, YELLOW)
                    dif+=1
                if number>=YELLOW_CREEP and number<=30:
                    pygame.time.set_timer(ENEMYRATE, t1/dif)
                    Enemy(STARTx, STARTy, RED)
                    
        for tow in towers:                
            scope = scope + tow.shotting(screen, all_enemies)
        MyCOINS = pygame.font.SysFont("monospace", 15)
        health = pygame.font.SysFont("monospace", 15)
        timer.tick(20)
        text3 = MyCOINS.render("FPS "+str(timer.get_fps()), 1, (10, 10, 10))
        text2 = health.render("Health"+str(hel), 1, (10, 10, 10))
        text1 = MyCOINS.render("Scope"+str(scope), 1, (10, 10, 10))
        screen.blit(text1, (5, 0))
        screen.blit(text2, (5, 15))
        screen.blit(text3, (5, 30))
        text3 = MyCOINS.render("Enemy "+str(number), 1, (10, 10, 10))
        screen.blit(text3, (5, 45))
        update_display(screen, sh_tow, 10, LAZCOST)
        update_display(screen, laz_tow, 45, SHORTCOST)
        
     
        pygame.display.flip()          # flip the screen 30 times a second  
        pygame.time.delay(1)
        
    #finish 
    screen.fill((100,100,100))
    health = pygame.font.SysFont("monospace", 40)
    over = health.render("GAME OVER", 1, (10, 10, 10))
    screen.blit(over, (WIN_WIDTH/2-100,WIN_HEIGHT/2-20))
    over = health.render("YOU LOSE", 1, (10, 10, 10))
    screen.blit(over, (WIN_WIDTH/2-100,WIN_HEIGHT/2+25))
            
    pygame.display.flip()
    pygame.time.delay(1000)

# main fuction                
if __name__ == "__main__":
    main()
    
