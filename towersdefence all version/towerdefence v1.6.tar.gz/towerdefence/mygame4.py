import pygame
import os
from settings import *
from pygame import *
from pygame.time import *
from tower import*
from enemyjourny import Enemy, Enemy_way, left_border





def main():
    pygame.init() 
    Enemy.image.append(pygame.image.load(os.path.join("data","babytux.png")))
    
    # 60 frame in second
    timer = pygame.time.Clock()
    timer.tick(5)
    x = 1000
    time.set_timer(SHOOT, t)
    time.set_timer(ENEMYRATE, t1)
    screen = pygame.display.set_mode(DISPLAY) 
    pygame.display.set_caption("Tower deffence") 
    bg = Surface((WIN_WIDTH,WIN_HEIGHT))
                                         
    bg.fill(Color(BACKGROUND_COLOR))     
    screen.blit(bg, (0,0)) 
    pygame.display.update()

    #way for enemy
    enemyway = pygame.sprite.Group()
    towers = pygame.sprite.Group()
    borders = pygame.sprite.Group()
    all_enemies = pygame.sprite.Group()
    
    bullets = pygame.sprite.Group()
    
    Enemy.groups = all_enemies
    x=y=0 
    for row in level: 
               for col in row: 
                      if col == "-":
                             way = Enemy_way(x,y)
                             way.draw(screen)
                             enemyway.add(way)
                             border = left_border(x,y)
                             borders.add(border)
                      if col == "s":
                             STARTx = x/PLATFORM_WIDTH
                             STARTy = y/PLATFORM_HEIGHT
                             way = Enemy_way(x,y)
                             border = left_border(x,y)
                             enemyway.add(way)
                             borders.add(border)
                      x += PLATFORM_WIDTH 
               y += PLATFORM_HEIGHT    
               x = 0               
    while 1: 
        for e in pygame.event.get(): 
            if e.type == QUIT:
                raise SystemExit, "QUIT"
            if e.type == pygame.MOUSEBUTTONUP:
                tow = create_tower(screen)
                towers.add(tow)
            if e.type == ENEMYRATE:
                Enemy(STARTx, STARTy)
                
        # display
        pygame.display.update()     
        screen.fill((255,0,0))
        pygame.time.delay(10)
        
        #draw ways
        enemyway.update()
        enemyway.draw(screen)
        #draw boders  
        borders.draw(screen)
        borders.update()
        #draw enemy 
        all_enemies.update(borders)        
        all_enemies.draw(screen)
        #tower and bullets
        for tow in towers:
            tow.update(all_enemies, screen)
        towers.draw(screen)
        pygame.display.flip()          # flip the screen 30 times a second  
        pygame.time.delay(30)
                
if __name__ == "__main__":
    main()
    
