import pygame
import os

#display
WIN_WIDTH = 800 
WIN_HEIGHT = 500

# resolution
DISPLAY = (WIN_WIDTH, WIN_HEIGHT)


# all  events 
ENEMYRATE, t1, trail = pygame.USEREVENT+1, 30000, []
SHOOT, t, trail = pygame.USEREVENT+2, 1000, []

#move speed
MOVE_SPEED = 6

#start point enemy
STARTx = 0
STARTy = 0


# gamespeed
DIFICULT = 10


# numbers of finished enemies
HEALTH = 1

#lazer color
lazcol = (150,150,150)

#colours
BACKGROUND_COLOR = "#004400"
PLATFORM_COLOR = "#FF6262"
PLATFORM_COLOR1 = "#006262"

#images for game
all_images = [pygame.image.load(os.path.join("data","blue.png")),
              pygame.image.load(os.path.join("data","yellow.png")),
              pygame.image.load(os.path.join("data","creep.png")),
              pygame.image.load(os.path.join("data","creep.png")),
              ]
all_t = pygame.image.load(os.path.join("data","mario.png"))


        # ALL FOR TOWERS
# shoot speed of short tower
VELOCITY = 10

#UPGADE TOWER LIMIT
UPGRADE = 3

#laser tower cost
LAZCOST = 15
#short tower cost
SHORTCOST = 1


          # lazer tower image  
all_t1 = [
          pygame.image.load(os.path.join("data","laztow.png")),
          pygame.image.load(os.path.join("data","laztow1.png")),
          pygame.image.load(os.path.join("data","laztow2.png")),
          pygame.image.load(os.path.join("data","laztow3.png")),
          pygame.image.load(os.path.join("data","laztow2.png")),

          # short tower image  
          pygame.image.load(os.path.join("data","mario.png")),
          pygame.image.load(os.path.join("data","laztow1.png")),
          pygame.image.load(os.path.join("data","laztow2.png")),
          pygame.image.load(os.path.join("data","laztow3.png")),
          pygame.image.load(os.path.join("data","laztow4.png")),
          pygame.image.load(os.path.join("data","laztow5.png")),

          ]
          
# way where enemy go "-"  
level = [
       "   ---              ",
       "   - -              ",
       "   - -              ",
       "s--- - ------------f",
       "     - -            ",
       "     - -            ",
       "     - -            ",
       "     - -            ",
       "     - -            ",
       "     ---            ",
       "                    ",
       ]


#nubers of platform
NUMBERS_HEIGHT = len(level)
NUMBERS_WIDTH = len(level[0])


#size of platform
PLATFORM_WIDTH = WIN_WIDTH/NUMBERS_WIDTH
PLATFORM_HEIGHT = WIN_HEIGHT/NUMBERS_HEIGHT

#type of enemy
BLUE = 0
BLUE_HEALTH = 5
YELLOW = 1
YELLOW_HEALTH = 10
RED = 2
RED_HEALTH = 40

# change difficalt when :
BLUE_CREEP = 5
YELLOW_CREEP = 10



#health bar
HEALTH_BAR_WIDTH = 20
HEALTH_BAR_HEIGHT = 5
HEALTH_BAR_BG_COLOR = (225, 0, 0)
HEALTH_BAR_COLOR = (0, 225, 0)
HEALTH_BAR_MARGIN = 3


