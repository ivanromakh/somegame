import pygame
import os
from pygame import *
from pygame.time import *
from settings import*
import math

def create_tower(screen, thistype, upgrade):
    positions = mouse.get_pos()
    row= positions[0]/PLATFORM_WIDTH  
    x = row*PLATFORM_WIDTH
    col= positions[1]/ PLATFORM_HEIGHT
    y =col* PLATFORM_HEIGHT
    # if not on enemy way
    if level[col][row] != '-':
        if thistype == 0:
            tower = ShortTower(x, y)
        else:
            tower = LazerTower(x, y)
        # center of tower
        center = (x+PLATFORM_WIDTH/2,y+PLATFORM_HEIGHT/2)
        return tower
    return 0





class LazerTower(sprite.Sprite):
    def __init__(self, x, y):
        sprite.Sprite.__init__(self)
        self.xvel = 0
        self.upgrade = 0
        self.image = all_t1[0]
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.bullets = pygame.sprite.Group()
        self.rect.y = y
        self.en_pos_x = 0
        self.en_pos_y = 0
        self.scopes = 0
        self.shoot = 0
        self.cost = LAZCOST
        self.damage = 1
        self.radius = 300
    def draw(self, screen): 
        screen.blit(self.image, (self.rect.x,self.rect.y))
    def update(self, myenemy):
        self.shoot = 1
        self.en_pos_x = myenemy.rect.center[0]  
        self.en_pos_y = myenemy.rect.center[1]
        myenemy.health-=1
        if myenemy.health == 0:
            myenemy.kill()
            self.scopes = 1
    def shotting(self, screen, allenemy):
        scop = 0
        if self.shoot == 1:
            pygame.draw.line(screen,(200,200,0), (self.rect.x,self.rect.y),(self.en_pos_x,self.en_pos_y),3)
            self.shoot = 0
        if self.scopes!=0:
            scop = self.scopes
            self.scopes = 0
        return scop
    def tow_upgrade(self):
        self.upgrade+=1
        self.image = all_t1[self.upgrade]




class ShortTower(sprite.Sprite):
    def __init__(self, x, y):
        sprite.Sprite.__init__(self)
        self.upgrade = 0
        self.image = all_t1[5]
        self.xvel = 0
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.bullets = pygame.sprite.Group()
        self.rect.y = y
        self.radius = 100
        self.cost = SHORTCOST
        self.damage = 1
    def draw(self, screen): 
        screen.blit(self.image, (self.rect.x,self.rect.y))
    def update(self, myenemy):
        shoot = Bullets(myenemy.rect, self.rect)
        self.bullets.add(shoot)
    def shotting(self, screen, allenemy):
        scop = 0
        for bult in self.bullets:
            scop = scop + bult.update(allenemy, self.damage)
        self.bullets.draw(screen)
        return scop
    def tow_upgrade(self):
        if self.upgrade <= UPGRADE:
            self.upgrade+=1
            self.damage+=1 
            self.image = all_t1[self.upgrade]
            return True
        else:
            return False
        





class Bullets(sprite.Sprite):
    def __init__(self, en_cord, tow_cord):
        sprite.Sprite.__init__(self)
        self.xvel = (VELOCITY*(en_cord.center[0] - tow_cord.center[0]))/(math.fabs(en_cord.center[0] - tow_cord.center[0])+math.fabs(en_cord.center[1] - tow_cord.center[1]))
        self.yvel = (VELOCITY*(en_cord.center[1] - tow_cord.center[1]))/(math.fabs(en_cord.center[0] - tow_cord.center[0])+math.fabs(en_cord.center[1] - tow_cord.center[1]))

        self.image = pygame.image.load(os.path.join("data","bullet.png"))

        self.rect = self.image.get_rect()
        self.rect.x = tow_cord.center[0]
        self.rect.y = tow_cord.center[1]
        
    def update(self, allenemies, damage):
        self.rect.x = self.rect.x + self.xvel
        self.rect.y = self.rect.y + self.yvel
        for enemy in allenemies:
            if sprite.collide_rect(self, enemy):
                enemy.health-=damage
                if enemy.health <= 0:
                    enemy.kill()
                    self.kill()
                    return 1
                self.kill()
        return 0
    def draw(self, screen):
        screen.blit(self.image, (self.rect.x,self.rect.y))
