import pygame
from pygame import *
from settings import*
import healthbar

class Enemy(pygame.sprite.Sprite):
    images = []
    def __init__(self, x, y, thistype):
        sprite.Sprite.__init__(self,self.groups)
        
        self.startX = x
        self.xvel = 1
        self.yvel = 0
        self.prev = "" 
        self.rotateX = 0
        self.rotateY = 0
        self.parityX = 0
        self.parityY = 0
        self.finish = 0
        self.startY = y
        self.thistype = thistype
        if thistype == BLUE:
            self.health = BLUE_HEALTH 
            self.image = all_images[0]
        if thistype == YELLOW:
            self.image = all_images[1]
            self.health = YELLOW_HEALTH
        if thistype == RED:
            self.image = all_images[2]
            self.health = RED_HEALTH
            
        
            
        self.rect = self.image.get_rect()
        self.myborders = pygame.sprite.Group()
        self.rect.x = x*PLATFORM_WIDTH
        self.rect.y = y*PLATFORM_HEIGHT+5
        self.setup_healthbar()
        
        
    def draw(self, screen): 
        screen.blit(self.image, (self.rect.x,self.rect.y))    
    def update(self, borders):
        self.healthbar.set_position((self.rect.x,self.rect.y-10))
        self.healthbar.update_health(self.health)
        for b in borders:
            if sprite.collide_rect(self, b):
                if self.myborders.has(b)==False:
                    self.myborders.add(b)
                    if(level[self.startY][self.startX+1]=="f"):
                        self.finish = 1
                    if(self.startX+1<NUMBERS_WIDTH and level[self.startY][self.startX+1]=="-"):
                        if self.yvel!=0 :
                            self.xvel=+1
                            if self.yvel>0:
                                self.rect.y = self.rect.y - 3
                            if self.yvel<0:
                                self.rect.y = self.rect.y + 3    

                            self.parityX = 1
                            self.yvel=0
                            break
                        if self.xvel == 1 and self.parityX == 0:
                            if self.rotateX != 0:
                                self.startX=self.startX+1
                                self.prev = "x"
                            self.rotateX = 1    
                            self.parityX = 1
                            break
                        self.xvel=+1
                        self.yvel=0
                        self.parityX = 0
                        break
                    if(self.prev != "y+"):
                        if(self.startY-1>=0 and level[self.startY-1][self.startX]=="-"):
                            self.prev = "y-"
                            if self.xvel==1:
                                self.xvel=0
                                self.yvel=-1
                                self.rect.x = self.rect.x - 3 
                                self.rotateY = 0
                                break
                            if self.parityY == 1:
                                self.startY=self.startY-1
                                self.parityY = 0
                                self.rotateY = 1
                                break
                            self.parityY = 1  
                            self.yvel=-1
                            break
                    if(self.prev != "y-"):
                        if(self.startY+1<PLATFORM_HEIGHT and level[self.startY+1][self.startX]=="-"):
                            self.prev = "y+"
                            if self.xvel==1:
                                self.xvel=0
                                self.yvel=+1
                                self.rect.x = self.rect.x - 3 
                                self.rotateY = 0 
                                break
                            if self.parityY == 1:
                                self.startY=self.startY+1
                                self.parityY = 0
                                self.rotateY = 1
                                break
                            self.parityY = 1  
                            self.yvel=+1
                            break             
        self.rect.x = self.rect.x + self.xvel
        self.rect.y = self.rect.y + self.yvel
    def setup_healthbar(self):
        health_pos = self.rect.x, self.rect.y-5
        self.healthbar = healthbar.Healthbar(health_pos, self.health)
        

    def paint_health(self, surface):
        self.healthbar.paint(surface)

    

class Way_borders(sprite.Sprite):
    def __init__(self, x, y, width, heigth):
        sprite.Sprite.__init__(self)
        self.startX = x*PLATFORM_WIDTH
        self.xvel = 0
        self.name = "border"
        self.id = x*y
        self.startY = y*PLATFORM_HEIGHT
        self.image = Surface((width, heigth))
        self.image.fill((0,100,0))
        self.rect = Rect(x, y, width, heigth) 
        self.rect.x = self.rect.x + self.xvel 
    def draw(self, screen): 
        screen.blit(self.image, (self.rect.x,self.rect.y))         

def finish(x, y):
    border = Way_borders(x+PLATFORM_WIDTH-2,y, 2, PLATFORM_HEIGHT)
    return border
def left_border(x, y):
    borders = pygame.sprite.Group()
    border = Way_borders(x,y, 2, PLATFORM_HEIGHT)
    borders.add(border)
    border = Way_borders(x,y, PLATFORM_WIDTH, 2)
    borders.add(border)
    border = Way_borders(x,y+PLATFORM_HEIGHT-2, PLATFORM_WIDTH, 2)
    borders.add(border)
    border = Way_borders(x+PLATFORM_WIDTH-2,y, 2, PLATFORM_HEIGHT)
    borders.add(border)
    return borders

# platforms  where enemy will go
class Enemy_way(sprite.Sprite):
    def __init__(self, x, y):
        sprite.Sprite.__init__(self)
        self.startX = x*PLATFORM_WIDTH
        self.xvel = 0
        self.name = "way"
        self.id = x*y
        self.startY = y*PLATFORM_HEIGHT
        self.image = Surface((PLATFORM_WIDTH,PLATFORM_HEIGHT))
        self.image.fill((0,0,0))
        self.rect = Rect(x, y, PLATFORM_WIDTH,PLATFORM_HEIGHT) 
        self.rect.x = self.rect.x + self.xvel 
    def draw(self, screen): 
        screen.blit(self.image, (self.rect.x,self.rect.y)) 

